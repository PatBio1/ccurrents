import { LightningElement } from 'lwc';
import labels from 'c/labelService';

export default class Centers extends LightningElement {

    labels = labels;

}