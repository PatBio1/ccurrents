import { LightningElement, track, api } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';

import { visitStatusToDisplayClass, visitOutcomeToDisplayClass } from "c/constants";
import RescheduleVisitModal from "c/rescheduleVisitModal";
import EnrollCardModal from "c/enrollCardModal";
import UpdateVisitOutcomeModal from "c/updateVisitOutcomeModal";

export default class DonorDot extends NavigationMixin(LightningElement)  {
    @track showpopover = false;
    @api initials;
    @api icon = 'standard:account';
    @api donor;
    @api appointment;
    @api centerId;
    @api popFlipYPoint;

    visitLink;
    donorLink;
    isPopupConfigured = false;
    popUpDirection;

    get hideName() {
        return true;
    }

    get donorLoyaltyLevel() {
        return (this.donor.loyaltyTierName);
    }

    get donorLoyaltyLevelDisplay() {
        return (this.donorLoyaltyLevel) ? this.donorLoyaltyLevel : "No Loyalty";
    }

    get cantUpdateOutcome() {
        let appointmentDatetime = new Date(this.appointment.appointmentDatetime);
        let targetDate = new Date();

        return (
            appointmentDatetime.getDate() !== targetDate.getDate() ||
            appointmentDatetime.getMonth() !== targetDate.getMonth() ||
            appointmentDatetime.getFullYear() !== targetDate.getFullYear() ||
            this.donor.status === "Complete" ||
            this.donor.outcome
        );
    }

    get cantReschedule() {
        return !this.canReschedule;
    }

    get canReschedule() {
        let appointmentDatetime = new Date(this.appointment.appointmentDatetime);
        let targetDate = new Date();

        return (
            (
                appointmentDatetime.getDate() === targetDate.getDate() &&
                appointmentDatetime.getMonth() === targetDate.getMonth() &&
                appointmentDatetime.getFullYear() === targetDate.getFullYear()
            ) &&
            this.donor.status !== "Complete" &&
            !this.donor.outcome
        );
    }

    get displayStatus() {
        return (this.donor.outcome) ? this.donor.outcome : this.donor.status;
    }

    get cantCancelVisit() {
        return (this.appointment.isInThePast || this.donor.status === "Complete" || this.donor.outcome === "Canceled");
    }

    get popupContainerClasses() {
        let baseClasses = ["slds-popover", "visit-popup-container"];

        if (this.popUpDirection === "Top") {
            baseClasses.push("slds-nubbin_bottom");
        } else {
            baseClasses.push("slds-nubbin_top");
        }

        return baseClasses.join(" ");
    }

    get avatarClasses() {
        let targetClasses = ['slds-m-right_small', 'donor-icon'];
        
        if (this.donor.outcome) {
            targetClasses.push(visitOutcomeToDisplayClass.get(this.donor.outcome));
        } else {
            targetClasses.push(visitStatusToDisplayClass.get(this.donor.status));
        }

        return targetClasses.join(" ");
    }

    get loyaltyBadgeDisplayClass() {
        const loyaltyLevelNameToClass = new Map([
            ["Donor (Default)", "regular-loyalty-badge"],
            ["Normal Donor +15", "regular-loyalty-badge"],
            ["Signature", "signature-loyalty-badge"],
            ["VIP", "vip-loyalty-badge"],
            ["Royal", "royal-loyalty-badge"]
        ]);

        return ["loyalty-badge", loyaltyLevelNameToClass.get(this.donor.loyaltyTierName) || "regular-loyalty-badge"].join(" ");
    }

    get isFirstVisit() {
        return this.donor.isFirstVisit;
    }

    get displaySpecialTasks() {
        if (this.isFirstVisit) {
            return false;
        }

        return (this.donor.visitNotes && this.donor.visitNotes.length > 0);
    }

    renderedCallback() {
        if (this.showpopover && !this.isPopupConfigured) {
            this.calculatePopupPosition();
        }

        this[NavigationMixin.GenerateUrl]({
            type: "standard__recordPage",
            attributes: {
                objectApiName: 'Contact',
                recordId: this.donor.donorId,
                actionName: 'view'
            }
        }).then(url => {
            if (this.donorLink !== url) {
                this.donorLink = url;
            }
        });
    }

    togglePopover() {
        if (!this.showpopover) {
            this.dispatchEvent(new CustomEvent('donorpopupopen'));
        }

        this.showpopover = !this.showpopover;
        this.isPopupConfigured = false;
    }

    hidePopover() {
        this.showpopover = false;
    }

    dragstart(event){
        this.showpopover = false;

        event.dataTransfer.setData("donorId", this.donor.donorId);
        event.dataTransfer.setData("donorName", this.donor.donorName);
        event.dataTransfer.setData("appointmentId", this.appointment.Id);
        event.dataTransfer.setData("appointmentTime", this.appointment.timeString);
        event.dataTransfer.setData("visitId", this.donor.visitId );
    }

    cancelVisit(event){
        const cancelVisitEvent = new CustomEvent("cancelvisit", {
            detail: {
                visitId:this.donor.visitId,
                appointmentId: this.appointment.Id,
                donorName: this.donor.donorName
            }
        });

        this.dispatchEvent(cancelVisitEvent);
    }

    calculatePopupPosition() {
        let popupContainer = this.template.querySelector("section.visit-popup-container");
        if (!popupContainer) {
            console.error("Couldn't find popup container");
            return;
        }

        let popOnTop = (this.template.host.getBoundingClientRect().y >= this.popFlipYPoint);
        if (popOnTop) {
            this.popUpDirection = "Top";
            popupContainer.style.top = "-218px";
        } else {
            this.popUpDirection = "Bottom";
            popupContainer.style.top = "66px";
        }

        this.isPopupConfigured = true;
    }

    handleInitReschedule(event) {
        let originDate = new Date(this.appointment.appointmentDatetime);
        originDate.setDate(originDate.getDate() + 1);

        RescheduleVisitModal.open({
            existingVisitAppointmentId: this.appointment.Id,
            existingVisitId: this.donor.visitId,
            donorId: this.donor.donorId,
            originDate: originDate,
            centerId: this.centerId,

            onvisitrescheduled: (event) => {
                this.dispatchEvent(new CustomEvent("visitrescheduled", { detail: {...event.detail} }));
            }
        });
    }

    handleInitEnrollCard(event) {
        EnrollCardModal.open({
            donorId: this.donor.donorId
        });
    }

    handleInitOutcomeUpdate(event) {
        UpdateVisitOutcomeModal.open({
            visitId: this.donor.visitId,

            onvisitoutcomeupdated: (event) => {
                this.dispatchEvent(new CustomEvent("visitoutcomeupdated", { detail: {...event.detail, appointmentId: this.appointment.Id} }));
            }
        });
    }

    @api closePopover() {
        this.showpopover = false;
        this.isPopupConfigured = false;
    }
}